function startScript() {
    var userValue = document.forms.form.user.value;
    if ( userValue.length <= 20 ) {
            window.open(`https://scratch.mit.edu/users/${userValue}/`);
    } else {
        alert("20文字以内にしてください。");
    }
}

document.getElementById('formactivity').addEventListener('click', startScript);